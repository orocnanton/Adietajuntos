<?php
/**
 * The custom post type file
 *
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage verano
 */

// Flush rewrite rules for custom post types
add_action( 'after_switch_theme', 'verano_custom_post' );
function verano_custom_post() {
	flush_rewrite_rules();
}


/*****************************
 *   Project custom type
 *****************************/
/*
function custom_post_project() { 
    
	register_post_type( 'project',
		array( 'labels' => array(
			     'name' => __( 'Projects', 'mrpress' ),
			     'singular_name' => __( 'Project', 'mrpress' ),
			),
			'public' => true,
            'has_archive' => true,
			'menu_position' => 8,
            'hierarchical' => true,
			'menu_icon' => 'dashicons-desktop',
			'supports' => array( 'title', 'editor', 'thumbnail', 'custom-fields', 'sticky')
		) 
	);
	
}

add_action( 'init', 'custom_post_project');
*/
	