<?php
/**
 * The front page file
 *
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage verano
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

	<div id="primary" class="content-area w3-col l12">
		<main id="main" class="site-main" role="main">

			<?php if ( is_home() && ! is_front_page() ) : ?>
				<header>
					<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
				</header>
			<?php endif; ?>
			
			<div class="slider-home w3-row">
                <?php if ( ! is_user_logged_in() ) :?>
                    <div class="flexslider w3-half">
                        <ul class="slides">
                            <?php if (function_exists( 'ot_get_option' )) {

                                /* get the slider array */
                                $slides = ot_get_option( 'slider', array() );
                                if ( ! empty( $slides )) {
                                    foreach ($slides as $slide) {
                                        echo '
								<li>
									<div class="w3-container">' . $slide['description'] . '</div>
								</li>';
                                    }
                                }
                            }
                            ?>
                        </ul>
                    </div>
                    <div class="w3-half w3-container"><?php echo do_shortcode('[ultimatemember form_id=1510]'); ?> </div>
	            <?php else : ?>
	                <div class="flexslider">
		                <ul class="slides">
			                <?php if (function_exists( 'ot_get_option' )) {

				                /* get the slider array */
				                $slides = ot_get_option( 'slider', array() );
				                if ( ! empty( $slides )) {
					                foreach ($slides as $slide) {
						                echo '
								<li class="w3-container">
									<div class="w3-content">' . $slide['description'] . '</div>
								</li>';
					                }
				                }
			                }
			                ?>
		                </ul>
	                </div>
	            <?php endif; ?>
            </div><!-- .header-image -->

			<div class="front-page presentacion">
				<?php if ( function_exists( 'ot_get_option' ) ) : ?>
					<?php $front_page_a_content = ot_get_option( 'front_page_a_content' ); ?>
					<div class="w3-content w3-container"><?php echo $front_page_a_content; ?></div>
				<?php endif; ?>
			</div>

			<div class="front-page destacados">
				<?php if ( is_active_sidebar( 'front-page-2' ) ) : ?>
					<aside id="front-button" class="widget-area w3-content w3-row" role="complementary">
						<?php dynamic_sidebar( 'front-page-2' ); ?>
					</aside><!-- .sidebar .widget-area -->

				<?php endif; ?>
			</div>

			<div class="front-page testimonios">
				<?php if ( function_exists( 'ot_get_option' ) ) : ?>
					<?php $front_page_b_content = ot_get_option( 'front_page_b_content' ); ?>
					<div class="w3-content w3-container w3-animate-left"><?php echo do_shortcode(get_option_tree( 'front_page_b_content' )); ?></div>
				<?php endif; ?>
			</div>
		
		<div class="front-page recent-post">
		<?php if ( is_active_sidebar( 'front-page-1' ) ) : ?>
			<aside id="front-top" class="widget-area w3-content w3-animate-bottom" role="complementary">
				<?php dynamic_sidebar( 'front-page-1' ); ?>
			</aside><!-- .sidebar .widget-area -->

		<?php endif; ?>
		</div>

		</main><!-- .site-main -->
	</div><!-- .content-area -->


<?php get_footer(); ?>